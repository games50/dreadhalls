Horrormaster & Horrorfind Fonts by Chad Savage
http://www.sinistervisions.com

Created 2004 for Horrorfind.com

Copyright 2004 Horrorfind.com. All rights reserved. You may install this font on your computer and use it for non-profit and personal purposes; you may NOT use it for commercial enterprises without the express consent of Horrorfind.com, LLC. You may not re-distribute this font. You may not offer it for download from your own site, but you are welcome to direct people to HorrorFind.com to download it there.

For free fonts you CAN use however you want, visit http://www.sinisterfonts.com.